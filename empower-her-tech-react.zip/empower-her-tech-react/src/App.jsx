import React from "react";

export default function App() {
  return (
    <div>
      <h1>Empower Her Tech</h1>
      <p>Votre code complet doit être collé ici depuis le canevas.</p>
    </div>
  );
}
